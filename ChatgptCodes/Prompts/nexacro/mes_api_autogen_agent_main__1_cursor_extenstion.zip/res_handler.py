def transform_nexacro_to_ui_table(network_data, response_mapping_data, nexacro_response):
    """
    서버의 넥사크로 응답 데이터를 최종 UI(Grid) 테이블 형식으로 변환합니다.
    (Contains 기반 1:N 매핑 및 무조건 인덱스 부여 로직 적용 완료)

    :param network_data: 서버 DVO -> UI 데이터셋 매핑 정보 (dict or list)
    :param response_mapping_data: UI 그리드 컬럼 매핑 정보 (list)
    :param nexacro_response: 실제 넥사크로 서버 응답 데이터 (dict)
    :return: 서버 DVO별로 매칭된 가능한 모든 UI 테이블 데이터 딕셔너리
    """
    result = {}

    # 1. Server Dataset -> UI Dataset (패킷 타겟) 매핑 딕셔너리 추출
    dataset_mapping = {}
    if isinstance(network_data, list):
        for api_info in network_data:
            dataset_mapping.update(api_info.get("datasetMapping", {}))
    elif isinstance(network_data, dict):
        dataset_mapping = network_data.get("datasetMapping", {})

    # 2. 서버 응답 데이터 순회 및 1:N 변환
    for server_ds_id, rows in nexacro_response.items():
        if server_ds_id not in dataset_mapping:
            continue

        # 네트워크에서 잡힌 타겟 이름 (예: dsMainDVOListAppend)
        packet_target_ds = dataset_mapping[server_ds_id].lower()

        # 3. [핵심] 양방향 Contains 로직으로 가능한 매핑 후보 '전부' 찾기
        matched_ui_grids = []
        for grid_info in response_mapping_data:
            ui_ds_id = grid_info.get("datasetId", "")
            if not ui_ds_id:
                continue

            ui_ds_lower = ui_ds_id.lower()

            # 하나가 다른 하나를 포함하면 무조건 후보군에 넣음 (1:N 허용)
            if ui_ds_lower in packet_target_ds or packet_target_ds in ui_ds_lower:
                matched_ui_grids.append(grid_info)

        # 화면에 바인딩 될만한 그리드가 아예 없으면 패스
        if not matched_ui_grids:
            continue

        result[server_ds_id] = {}

        # 4. 매칭된 '모든' 후보 그리드 조합을 다 만들어냄
        for grid_info in matched_ui_grids:
            ui_ds_id = grid_info.get("datasetId")
            comp_id = grid_info.get("compId", "UnknownGrid")  # 중복 구분을 위해 compId 가져옴
            columns_info = grid_info.get("columns", [])

            table_data = []

            for row in rows:
                transformed_row = {}
                for col in columns_info:
                    ui_header = col.get("uiHeader", "Unknown")
                    server_field = col.get("serverField")
                    is_expression = col.get("isExpression", False)

                    if is_expression:
                        # eval(expr)식인 경우, 파싱하지 않고 수식 문자열 자체를 노출
                        transformed_row[ui_header] = server_field
                    else:
                        # 실제 데이터 매핑 (서버 필드값이 없을 경우 None/null 처리)
                        transformed_row[ui_header] = row.get(server_field)

                table_data.append(transformed_row)

            # 5. [수정됨] 데이터 일치 여부 묻지도 따지지도 않고, 키가 겹치면 무조건 인덱스(_1, _2...) 부여
            base_grid_key = f"{ui_ds_id} ({comp_id})"
            grid_key = base_grid_key

            idx = 1
            # 딕셔너리에 이미 해당 키가 존재하면, 존재하지 않을 때까지 숫자를 올림
            while grid_key in result[server_ds_id]:
                grid_key = f"{base_grid_key}_{idx}"
                idx += 1

            # 최종 딕셔너리 적재
            result[server_ds_id][grid_key] = table_data

    return result