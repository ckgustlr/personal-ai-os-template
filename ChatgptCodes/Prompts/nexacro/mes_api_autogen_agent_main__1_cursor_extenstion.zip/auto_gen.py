import json
import re

from params import NETWORK_JSON, REQ_JSON, RES_JSON


def sanitize_enum_key(text):
    """
    UI 텍스트를 Enum 변수명 컨벤션으로 변환
    예: "WATER_PROOF_TESTER(FOR_PART)" -> "WATER_PROOF_TESTER_FOR_PART"
    """
    # 1. 대문자 변환
    text = text.upper()
    # 2. 공백 및 특수문자((, ), /, -, 등)를 언더바(_)로 치환
    text = re.sub(r'[^A-Z0-9]', '_', text)
    # 3. 연속된 언더바 제거 및 앞뒤 언더바 정리
    text = re.sub(r'_+', '_', text).strip('_')
    return text


def generate_rest_api_file(network_json, req_json, res_json):
    api_info = network_json[0] if network_json else {}
    target_url = api_info.get("url", "nexacro.do")

    req_dvos = api_info.get("requestTargetDVOs", {})
    req_dvo_name = list(req_dvos.keys())[0] if req_dvos else "UnknownRequestDVO"
    req_columns = req_dvos.get(req_dvo_name, [])

    res_dvos = api_info.get("responseTargetDVOs", {})
    res_dvo_name = list(res_dvos.keys())[0] if res_dvos else "UnknownResponseDVO"

    enums_code = ""
    pydantic_fields = ""

    req_binds = req_json.get("simpleBinds", [])
    bind_map = {bind["columnId"]: bind for bind in req_binds}

    for col in req_columns:
        bind_info = bind_map.get(col)

        if bind_info:
            label = bind_info["uiLabel"]
            options = bind_info.get("options", [])

            if options:
                # Enum 클래스 생성
                enum_class_name = f"{sanitize_enum_key(col)}_Enum"
                enums_code += f"class {enum_class_name}(str, Enum):\n"

                # [추가됨] 중복 Enum Key를 추적하기 위한 딕셔너리
                seen_keys = {}

                for opt in options:
                    # 1. 일단 치환 시도
                    raw_ui_text = opt.get('uiText', '')
                    enum_key = sanitize_enum_key(raw_ui_text)

                    # 2. 만약 빈 칸이거나 특수문자만 있어서 빈 문자열이 되었다면?
                    if not enum_key:
                        fallback_val = sanitize_enum_key(opt.get('serverValue', ''))
                        enum_key = f"VAL_{fallback_val}" if fallback_val else "EMPTY_OPTION"

                    # 3. 변수명이 숫자로 시작할 경우 앞에 'V_' 추가
                    if enum_key[0].isdigit():
                        enum_key = f"V_{enum_key}"

                    # 4. [추가됨] 중복 키 카운팅 및 네이밍 로직 (_1, _2 ...)
                    if enum_key in seen_keys:
                        seen_keys[enum_key] += 1
                        final_enum_key = f"{enum_key}_{seen_keys[enum_key]}"
                    else:
                        seen_keys[enum_key] = 0
                        final_enum_key = enum_key

                    enums_code += f"    {final_enum_key} = \"{opt.get('serverValue', '')}\"  # {raw_ui_text}\n"
                enums_code += "\n"

                # Pydantic 필드 (Swagger 설명 추가)
                pydantic_fields += f"    {col}: {enum_class_name} = Field(None, description=\"{label}\")\n"
            else:
                pydantic_fields += f"    {col}: str = Field(\"\", description=\"{label}\")\n"
        else:
            pydantic_fields += f"    {col}: str = Field(\"\", description=\"[Unmapped Field]\")\n"

    # Response Mapping (Swagger 결과 구조용)
    res_mapping_code = ""
    res_grid = res_json[0] if isinstance(res_json, list) and len(res_json) > 0 else {}
    res_columns = res_grid.get("columns", [])

    for col in res_columns:
        header = col.get("uiHeader", "Unknown_Header")
        field = col.get("serverField", "")
        is_expr = col.get("isExpression", False)

        if is_expr:
            safe_field = field.replace('"', "'")
            res_mapping_code += f"                \"{header}\": \"[EVAL_REQUIRED] {safe_field}\",\n"
        else:
            res_mapping_code += f"                \"{header}\": item.get(\"{field}\", \"\"),\n"

    # XML 조립용
    xml_col_info = "".join([f"            <Column id=\"{c}\" type=\"STRING\" size=\"256\" />\n" for c in req_columns])
    xml_row_data = "".join([
        f"                <Col id=\"{c}\">{{getattr(req.{c}, 'value', req.{c}) if req.{c} is not None else ''}}</Col>\n"
        for c in req_columns
    ])

    # 최종 코드 템플릿
    return f"""from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from enum import Enum
from typing import List, Optional, Any
import requests
import xml.etree.ElementTree as ET
import uvicorn

app = FastAPI(title="Nexacro G-MES Wrapper API", version="1.0.0")

# --- 자동 생성된 Enum (컨벤션 적용) ---
{enums_code}

# --- Request 스키마 (Swagger 표시용) ---
class ApiRequest(BaseModel):
{pydantic_fields.rstrip()}

class ApiResponse(BaseModel):
    status: str = Field(..., example="success")
    data: List[Any]

@app.post("/api/{req_dvo_name}", response_model=ApiResponse, tags=["MES Operations"])
def execute_{req_dvo_name}(
    req: ApiRequest, 
    token_id: str = Header(..., alias="X-Token-Id", description="MES 인증 토큰 (tokenId)"),
    refresh_token_id: str = Header(..., alias="X-Refresh-Token-Id", description="Refresh 토큰 (refreshTokenId)")
):
    \"\"\"
    넥사크로 {req_dvo_name} 호출 API
    \"\"\"

    # 1. 껍데기 템플릿 로드
    try:
        with open("base_template.xml", "r", encoding="utf-8") as f:
            template = f.read()
    except FileNotFoundError:
        raise HTTPException(status_code=500, detail="base_template.xml missing")

    # 2. 비즈니스 페이로드 생성
    business_payload = f\"\"\"
    <Dataset id="{req_dvo_name}">
        <ColumnInfo>
{xml_col_info.rstrip()}
        </ColumnInfo>
        <Rows>
            <Row>
{xml_row_data.rstrip()}
            </Row>
        </Rows>
    </Dataset>
    \"\"\"

    # 3. XML 조립
    final_xml = template.replace("{{{{BUSINESS_PAYLOAD}}}}", business_payload)
    final_xml = final_xml.replace("{{{{TOKEN_ID}}}}", token_id)
    final_xml = final_xml.replace("{{{{REFRESH_TOKEN_ID}}}}", refresh_token_id)
    final_xml = final_xml.replace("{{{{OUT_DATASET}}}}", "{res_dvo_name},anyframeDVO")

    # =========================================================================
    # 4. 실제 MES 서버로 통신 전송
    # =========================================================================
    url = "http://gumimes4.sec.samsung.net/mes4/rm/ext.do" # 실제 MES 도메인으로 변경 필요, 추후 url주소까지 자동 수집 할것.
    headers = {{"Content-Type": "application/xml"}}

    response = requests.post(url, data=final_xml.encode('utf-8'), headers=headers)

    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=f"MES 서버 에러: {{response.status_code}}")

    # =========================================================================
    # 5. 넥사크로 응답 XML 파싱 로직
    # =========================================================================
    parsed_items = []
    try:
        root = ET.fromstring(response.text)

        # 타겟 Response Dataset 찾기
        dataset = root.find(f".//Dataset[@id='{res_dvo_name}']")
        if dataset is not None:
            # 모든 Row 순회
            for row in dataset.findall(".//Row"):
                item_dict = {{}}
                # Row 안의 모든 Col 순회하여 딕셔너리로 변환
                for col in row.findall("Col"):
                    col_id = col.get("id")
                    item_dict[col_id] = col.text if col.text else ""
                parsed_items.append(item_dict)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"응답 XML 파싱 실패: {{str(e)}}")

    # =========================================================================
    # 6. Response UI 헤더 매핑
    # =========================================================================
    result = []
    for item in parsed_items:
        result.append({{
{res_mapping_code.rstrip()}
        }})

    return {{"status": "success", "data": result}}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5432)
"""


# =========================================================================
# 실행 방법
# =========================================================================
if __name__ == "__main__":
    # 추출한 JSON 객체를 파라미터로 넘겨줍니다.
    final_code_string = generate_rest_api_file(
        json.loads(NETWORK_JSON),
        json.loads(REQ_JSON),
        json.loads(RES_JSON)
    )

    # 파일 쓰기
    with open("rest_api.py", "w", encoding="utf-8") as f:
        f.write(final_code_string)