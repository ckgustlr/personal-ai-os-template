from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from enum import Enum
from typing import List, Optional, Any
import requests
import xml.etree.ElementTree as ET
import uvicorn

app = FastAPI(title="Nexacro G-MES Wrapper API", version="1.0.0")

# --- 자동 생성된 Enum (컨벤션 적용) ---
class LOSSSTATUS_Enum(str, Enum):
    ALL = ""  # All
    VAL_I = "I"  # 진행
    VAL_C = "C"  # 종료
    VAL_XA00 = "XA00"  # 미등록

class LOSSAPPLY_Enum(str, Enum):
    ALL = ""  # All
    VAL_Y = "Y"  # 적용
    VAL_N = "N"  # 미적용

class LOSSTYPE_Enum(str, Enum):
    ALL = ""  # All
    VAL_E = "E"  # 설비
    VAL_Q = "Q"  # 품질
    VAL_R = "R"  # 자재
    VAL_Z = "Z"  # 기타

class LOSSSHIFT_Enum(str, Enum):
    ALL = ""  # All
    V_1_SHIFT = "1"  # 1 Shift
    V_2_SHIFT = "2"  # 2 Shift
    V_3_SHIFT = "3"  # 3 Shift



# --- Request 스키마 (Swagger 표시용) ---
class ApiRequest(BaseModel):
    fromDate: str = Field("", description="매핑실패")
    toDate: str = Field("", description="매핑실패")
    lossStatus: LOSSSTATUS_Enum = Field(None, description="상태")
    lossApply: LOSSAPPLY_Enum = Field(None, description="적용여부")
    lossType: LOSSTYPE_Enum = Field(None, description="유실유형")
    lossShift: LOSSSHIFT_Enum = Field(None, description="교대조")
    lossOccTypeCode: str = Field("", description="[Unmapped Field]")
    tmpntGubunCode: str = Field("", description="[Unmapped Field]")
    line: str = Field("", description="[Unmapped Field]")
    proc: str = Field("", description="[Unmapped Field]")
    lossStartDt: str = Field("", description="[Unmapped Field]")
    part: str = Field("", description="[Unmapped Field]")
    fct: str = Field("", description="[Unmapped Field]")
    orgGbm: str = Field("", description="[Unmapped Field]")
    inclRestMop: str = Field("", description="[Unmapped Field]")
    paramPlant: str = Field("", description="[Unmapped Field]")

class ApiResponse(BaseModel):
    status: str = Field(..., example="success")
    data: List[Any]

@app.post("/api/filterGrdMain", response_model=ApiResponse, tags=["MES Operations"])
def execute_filterGrdMain(
    req: ApiRequest, 
    token_id: str = Header(..., alias="X-Token-Id", description="MES 인증 토큰 (tokenId)"),
    refresh_token_id: str = Header(..., alias="X-Refresh-Token-Id", description="Refresh 토큰 (refreshTokenId)")
):
    """
    넥사크로 filterGrdMain 호출 API
    """

    # 1. 껍데기 템플릿 로드
    try:
        with open("base_template.xml", "r", encoding="utf-8") as f:
            template = f.read()
    except FileNotFoundError:
        raise HTTPException(status_code=500, detail="base_template.xml missing")

    # 2. 비즈니스 페이로드 생성
    business_payload = f"""
    <Dataset id="filterGrdMain">
        <ColumnInfo>
            <Column id="fromDate" type="STRING" size="256" />
            <Column id="toDate" type="STRING" size="256" />
            <Column id="lossStatus" type="STRING" size="256" />
            <Column id="lossApply" type="STRING" size="256" />
            <Column id="lossType" type="STRING" size="256" />
            <Column id="lossShift" type="STRING" size="256" />
            <Column id="lossOccTypeCode" type="STRING" size="256" />
            <Column id="tmpntGubunCode" type="STRING" size="256" />
            <Column id="line" type="STRING" size="256" />
            <Column id="proc" type="STRING" size="256" />
            <Column id="lossStartDt" type="STRING" size="256" />
            <Column id="part" type="STRING" size="256" />
            <Column id="fct" type="STRING" size="256" />
            <Column id="orgGbm" type="STRING" size="256" />
            <Column id="inclRestMop" type="STRING" size="256" />
            <Column id="paramPlant" type="STRING" size="256" />
        </ColumnInfo>
        <Rows>
            <Row>
                <Col id="fromDate">{getattr(req.fromDate, 'value', req.fromDate) if req.fromDate is not None else ''}</Col>
                <Col id="toDate">{getattr(req.toDate, 'value', req.toDate) if req.toDate is not None else ''}</Col>
                <Col id="lossStatus">{getattr(req.lossStatus, 'value', req.lossStatus) if req.lossStatus is not None else ''}</Col>
                <Col id="lossApply">{getattr(req.lossApply, 'value', req.lossApply) if req.lossApply is not None else ''}</Col>
                <Col id="lossType">{getattr(req.lossType, 'value', req.lossType) if req.lossType is not None else ''}</Col>
                <Col id="lossShift">{getattr(req.lossShift, 'value', req.lossShift) if req.lossShift is not None else ''}</Col>
                <Col id="lossOccTypeCode">{getattr(req.lossOccTypeCode, 'value', req.lossOccTypeCode) if req.lossOccTypeCode is not None else ''}</Col>
                <Col id="tmpntGubunCode">{getattr(req.tmpntGubunCode, 'value', req.tmpntGubunCode) if req.tmpntGubunCode is not None else ''}</Col>
                <Col id="line">{getattr(req.line, 'value', req.line) if req.line is not None else ''}</Col>
                <Col id="proc">{getattr(req.proc, 'value', req.proc) if req.proc is not None else ''}</Col>
                <Col id="lossStartDt">{getattr(req.lossStartDt, 'value', req.lossStartDt) if req.lossStartDt is not None else ''}</Col>
                <Col id="part">{getattr(req.part, 'value', req.part) if req.part is not None else ''}</Col>
                <Col id="fct">{getattr(req.fct, 'value', req.fct) if req.fct is not None else ''}</Col>
                <Col id="orgGbm">{getattr(req.orgGbm, 'value', req.orgGbm) if req.orgGbm is not None else ''}</Col>
                <Col id="inclRestMop">{getattr(req.inclRestMop, 'value', req.inclRestMop) if req.inclRestMop is not None else ''}</Col>
                <Col id="paramPlant">{getattr(req.paramPlant, 'value', req.paramPlant) if req.paramPlant is not None else ''}</Col>
            </Row>
        </Rows>
    </Dataset>
    """

    # 3. XML 조립
    final_xml = template.replace("{{BUSINESS_PAYLOAD}}", business_payload)
    final_xml = final_xml.replace("{{TOKEN_ID}}", token_id)
    final_xml = final_xml.replace("{{REFRESH_TOKEN_ID}}", refresh_token_id)
    final_xml = final_xml.replace("{{OUT_DATASET}}", "listGrdMain2,anyframeDVO")

    # =========================================================================
    # 4. 실제 MES 서버로 통신 전송
    # =========================================================================
    url = "http://gumimes4.sec.samsung.net/mes4/rm/ext.do" # 실제 MES 도메인으로 변경 필요, 추후 url주소까지 자동 수집 할것.
    headers = {"Content-Type": "application/xml"}

    response = requests.post(url, data=final_xml.encode('utf-8'), headers=headers)

    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail=f"MES 서버 에러: {response.status_code}")

    # =========================================================================
    # 5. 넥사크로 응답 XML 파싱 로직
    # =========================================================================
    parsed_items = []
    try:
        root = ET.fromstring(response.text)

        # 타겟 Response Dataset 찾기
        dataset = root.find(f".//Dataset[@id='listGrdMain2']")
        if dataset is not None:
            # 모든 Row 순회
            for row in dataset.findall(".//Row"):
                item_dict = {}
                # Row 안의 모든 Col 순회하여 딕셔너리로 변환
                for col in row.findall("Col"):
                    col_id = col.get("id")
                    item_dict[col_id] = col.text if col.text else ""
                parsed_items.append(item_dict)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"응답 XML 파싱 실패: {str(e)}")

    # =========================================================================
    # 6. Response UI 헤더 매핑
    # =========================================================================
    result = []
    for item in parsed_items:
        result.append({
                "헤더없음": item.get("nm_ko", ""),
        })

    return {"status": "success", "data": result}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5432)
