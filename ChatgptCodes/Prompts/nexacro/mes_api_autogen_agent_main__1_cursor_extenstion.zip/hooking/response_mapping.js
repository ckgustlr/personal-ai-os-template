function extractGridMappingsStructural() {
    let app = nexacro.getApplication();
    let gridMappings = [];
    let visited = new Set();

    // 구조적 매핑의 핵심 함수
    function extractStructuralMapping(gridObj) {
        let mappingData = {
            compId: gridObj.name || gridObj.id,
            datasetId: gridObj.binddataset,
            columns: []
        };

        let headCount = gridObj.getCellCount("Head");
        let bodyCount = gridObj.getCellCount("Body");

        // 1. Head(헤더) 셀들의 좌표 지도(Map) 생성
        let headCells = [];
        for (let i = 0; i < headCount; i++) {
            let text = gridObj.getCellProperty("Head", i, "text") || "";
            text = text.replace(/\r\n|\n/g, " ").replace(/<[^>]*>?/gm, '').trim();

            // 좌표 정보 추출 (없으면 기본값 세팅)
            let col = gridObj.getCellProperty("Head", i, "col") || 0;
            let colspan = gridObj.getCellProperty("Head", i, "colspan") || 1;
            let row = gridObj.getCellProperty("Head", i, "row") || 0;

            if (text) {
                headCells.push({ text: text, startCol: col, endCol: col + colspan - 1, row: row });
            }
        }

        // 2. Body(데이터) 셀을 순회하며 좌표를 기준으로 Head 찾기
        for (let i = 0; i < bodyCount; i++) {
            let bodyText = gridObj.getCellProperty("Body", i, "text") || "";
            let col = gridObj.getCellProperty("Body", i, "col") || 0;

            let fieldId = "";
            let isExpr = false;

            if (typeof bodyText === "string") {
                if (bodyText.startsWith("bind:")) fieldId = bodyText.replace("bind:", "");
                else if (bodyText.startsWith("expr:")) { isExpr = true; fieldId = bodyText; }
            }

            if (!fieldId) continue; // 바인딩 안 된 셀은 무시

            // 3. 핀포인트 매칭: 현재 Body 셀의 열(col)을 포함하고 있는 모든 Head 셀 찾기
            let matchingHeads = headCells.filter(h => h.startCol <= col && col <= h.endCol);

            // Row(행) 기준으로 오름차순 정렬 (위에서 아래 순서로)
            matchingHeads.sort((a, b) => a.row - b.row);

            let uiHeaderLabel = "헤더없음";
            if (matchingHeads.length > 0) {
                // 다중/병합 헤더일 경우 "상위헤더 > 하위헤더" 형태로 조립 (예: "목표건수 > 실행")
                uiHeaderLabel = matchingHeads.map(h => h.text).join(" > ");
            }

            mappingData.columns.push({
                uiHeader: uiHeaderLabel,
                serverField: fieldId,
                isExpression: isExpr,
                _gridCol: col // 검증용 좌표값 추가
            });
        }
        return mappingData;
    }

    // 메모리 딥 스캔 함수 (이전과 동일하게 무한 탐색)
    function scanMemory(obj, path) {
        if (!obj || typeof obj !== 'object') return;
        if (visited.has(obj)) return;
        visited.add(obj);

        if (typeof obj.getCellCount === "function" && typeof obj.getCellProperty === "function") {
            let dsName = obj.binddataset || "";
            if (dsName.indexOf("CatCommonTreeNode") === -1) {
                let result = extractStructuralMapping(obj);
                if (result.columns.length > 0) gridMappings.push(result);
            }
        }

        if (obj.all) {
            for (let i = 0; i < obj.all.length; i++) scanMemory(obj.all[i], path + ".all[" + i + "]");
        }
        if (obj.components) {
            for (let i = 0; i < obj.components.length; i++) scanMemory(obj.components[i], path + ".components[" + i + "]");
        }
        if (obj.form) scanMemory(obj.form, path + ".form");
        if (obj.tabpages) {
            for (let i = 0; i < obj.tabpages.length; i++) scanMemory(obj.tabpages[i].form, path + ".tabpages[" + i + "]");
        }
        if (obj.frames) {
            for (let i = 0; i < obj.frames.length; i++) scanMemory(obj.frames[i], path + ".frames[" + i + "]");
        }
    }

    try {
        scanMemory(app.mainframe, "app.mainframe");
        let popups = nexacro.getPopupFrames ? nexacro.getPopupFrames() : null;
        if (popups) {
            for (let i = 0; i < popups.length; i++) scanMemory(popups[i], "popup[" + i + "]");
        }
    } catch (e) {
        console.error("탐색 에러: " + e.message);
    }

    console.log("�� [구조적 1:1 매핑 결과 JSON]");
    console.log(JSON.stringify(gridMappings, null, null));

    return gridMappings;
}

extractGridMappingsStructural();