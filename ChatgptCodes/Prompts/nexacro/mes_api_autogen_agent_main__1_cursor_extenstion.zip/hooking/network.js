// 1. 글로벌 저장소 초기화
window.mesApiStore = [];
window.exactDatasetMapping = {}; // 트랜잭션 1차 매핑 기록용
window.datasetCopyHistory = {};  // 버퍼 -> 최종 UI 복사 기록용

// 2. 블랙리스트 설정
const BLACKLIST_DVO = [
    "anyframeDVO", "eventLoggingDVOList", "itemFilterDVO",
    "TbmSmCommEnvDVO", "loggingDVOList", "categoryDVO", "clientDateTimeDVO"
];
const BLACKLIST_FIELDS = [
    "_dynamicColumnList", "_status", "_checked", "_action", "_RowType_"
];

// =========================================
// [HOOK 1] 넥사크로 Transaction API 후킹 (1차 매핑 포착)
// =========================================
if (!window._originalTransaction) {
    window._originalTransaction = nexacro.Form.prototype.transaction;
    nexacro.Form.prototype.transaction = function() {
        let strOutDatasets = arguments[3];
        if (strOutDatasets && typeof strOutDatasets === "string") {
            let pairs = strOutDatasets.split(/\s+/);
            pairs.forEach(p => {
                if (p.includes("=")) {
                    let parts = p.split("=");
                    window.exactDatasetMapping[parts[1].trim()] = parts[0].trim();
                }
            });
        }
        return window._originalTransaction.apply(this, arguments);
    };
}

// =========================================
// [HOOK 2] 넥사크로 copyData API 후킹 (최종 UI 테이블 추적)
// =========================================
if (!window._originalCopyData) {
    window._originalCopyData = nexacro.NormalDataset.prototype.copyData;
    nexacro.NormalDataset.prototype.copyData = function(sourceDataset) {
        if (sourceDataset && sourceDataset.id) {
            window.datasetCopyHistory[sourceDataset.id] = this.id;
            // 로깅이 너무 많으면 아래 줄은 주석 처리하셔도 됩니다.
            console.log(`�� [Data Copy] ${sourceDataset.id} ➡️ ${this.id}`);
        }
        return window._originalCopyData.apply(this, arguments);
    };
}

// =========================================
// [CORE UTILS] 패킷 파싱 및 스마트 매핑 로직
// =========================================
function getDatasetMapping(text) {
    if (!text) return { targetList: [], mapping: {} };
    let rawTargets = "";
    const xmlMatch = text.match(/<Parameter id="outDataset">([^<]+)<\/Parameter>/);
    if (xmlMatch) rawTargets = xmlMatch[1];
    const ssvMatch = text.match(/outDataset[^=]*=(?:")?([^\u001e"]+)/);
    if (!xmlMatch && ssvMatch) rawTargets = ssvMatch[1];

    if (!rawTargets) return { targetList: [], mapping: {} };

    let targetList = [];
    let mapping = {};
    let parts = rawTargets.split(/,|\s+/);

    parts.forEach(pair => {
        let cleanPair = pair.trim();
        if (!cleanPair) return;

        if (cleanPair.includes("=")) {
            let splitData = cleanPair.split("=");
            let frontDs = splitData[0].trim();
            let serverDs = splitData[1].trim();
            if (!BLACKLIST_DVO.includes(serverDs)) {
                targetList.push(serverDs);
                mapping[serverDs] = frontDs;
            }
        } else {
            if (!BLACKLIST_DVO.includes(cleanPair)) {
                targetList.push(cleanPair);
                mapping[cleanPair] = cleanPair;
            }
        }
    });
    return { targetList, mapping };
}

function parseTargetSchema(text, targetList, isRequest) {
    if (!text) return {};
    let result = {};
    let allowedTargets = isRequest ? null : targetList;

    if (text.includes("<?xml") || text.includes("<Root")) {
        const dsMatches = text.split(/<Dataset id="/).slice(1);
        dsMatches.forEach(dsBlock => {
            const dsId = dsBlock.split('"')[0];
            if (!BLACKLIST_DVO.includes(dsId) && (!allowedTargets || allowedTargets.includes(dsId))) {
                const colMatches = [...dsBlock.matchAll(/<Column id="([^"]+)"/g)]
                    .map(m => m[1])
                    .filter(col => !BLACKLIST_FIELDS.includes(col));
                if (colMatches.length > 0) result[dsId] = colMatches;
            }
        });
    } else if (text.startsWith("SSV:")) {
        const lines = text.split("\u001e");
        let currentDs = null;
        lines.forEach(line => {
            if (line.startsWith("Dataset:")) {
                const dsId = line.split(":")[1];
                if (!BLACKLIST_DVO.includes(dsId) && (!allowedTargets || allowedTargets.includes(dsId))) {
                    currentDs = dsId;
                } else {
                    currentDs = null;
                }
            } else if (currentDs && line.includes("_RowType_") && !result[currentDs]) {
                result[currentDs] = line.split("\u001f")
                    .map(c => c.split(":")[0])
                    .filter(c => c !== "" && !BLACKLIST_FIELDS.includes(c));
            }
        });
    }
    return result;
}

// �� [핵심] 3단계 추적을 통해 최종 UI 데이터셋을 알아내는 스마트 함수
function resolveFinalUIDataset(serverDs, payloadMapping) {
    // 1단계: Transaction 후킹 기록 우선 확인 -> 없으면 패킷 Payload 매핑 -> 없으면 자기 자신
    let initialLocalDs = window.exactDatasetMapping[serverDs] || payloadMapping[serverDs] || serverDs;

    // 2단계: copyData 후킹 기록 확인 (Input 버퍼에서 찐 UI 테이블로 넘어갔는지?)
    let finalUIDs = window.datasetCopyHistory[initialLocalDs] || initialLocalDs;

    return finalUIDs;
}

// =========================================
// [NETWORK HOOKS] XHR / Fetch 가로채기
// =========================================
const originalOpen = XMLHttpRequest.prototype.open;
const originalSend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function(method, url) {
    this._url = url;
    return originalOpen.apply(this, arguments);
};

XMLHttpRequest.prototype.send = function(body) {
    const reqText = body ? body.toString() : "";

    this.addEventListener('load', function() {
        const resText = this.responseText || "";
        const mappingInfo = getDatasetMapping(reqText);

        if (mappingInfo.targetList.length === 0) return;

        // 지연 실행 (copyData가 완료될 시간을 주기 위해 약간의 딜레이 후 파싱)
        setTimeout(() => {
            const reqData = parseTargetSchema(reqText, mappingInfo.targetList, true);
            const resData = parseTargetSchema(resText, mappingInfo.targetList, false);

            if (Object.keys(reqData).length > 0 || Object.keys(resData).length > 0) {
                let smartMapping = {};
                mappingInfo.targetList.forEach(serverDs => {
                    // 추적기 로직을 태워서 최종 테이블명 산출
                    smartMapping[serverDs] = resolveFinalUIDataset(serverDs, mappingInfo.mapping);
                });

                window.mesApiStore.push({
                    url: this._url.split('?')[0].split('/').pop(),
                    targetsFound: mappingInfo.targetList,
                    datasetMapping: smartMapping, // �� 추적 완료된 다이렉트 매핑!
                    requestTargetDVOs: reqData,
                    responseTargetDVOs: resData
                });
            }
        }, 100); // 0.1초 딜레이
    });
    return originalSend.apply(this, arguments);
};

// Fetch 가로채기
const originalFetch = window.fetch;
window.fetch = async function(...args) {
    const url = typeof args[0] === 'string' ? args[0] : args[0].url;
    const config = args[1];
    const response = await originalFetch.apply(this, args);

    const reqText = config && config.body ? config.body.toString() : "";
    const clone = response.clone();

    clone.text().then(resText => {
        const mappingInfo = getDatasetMapping(reqText);
        if (mappingInfo.targetList.length === 0) return;

        setTimeout(() => {
            const reqData = parseTargetSchema(reqText, mappingInfo.targetList, true);
            const resData = parseTargetSchema(resText, mappingInfo.targetList, false);

            if (Object.keys(reqData).length > 0 || Object.keys(resData).length > 0) {
                let smartMapping = {};
                mappingInfo.targetList.forEach(serverDs => {
                    smartMapping[serverDs] = resolveFinalUIDataset(serverDs, mappingInfo.mapping);
                });

                window.mesApiStore.push({
                    url: url.split('?')[0].split('/').pop(),
                    targetsFound: mappingInfo.targetList,
                    datasetMapping: smartMapping, // �� 추적 완료된 다이렉트 매핑!
                    requestTargetDVOs: reqData,
                    responseTargetDVOs: resData
                });
            }
        }, 100);
    }).catch(e => {});
    return response;
};

// =========================================
// [EXPORT] 결과물 출력 함수
// =========================================
window.exportTargetAPI = function() {
    console.clear();
    console.log(JSON.stringify(window.mesApiStore, null, null));
};

console.log("✅ 넥사크로 G-MES 통합 마스터 후킹 스크립트 구동 완료! 이제 조회를 실행하세요.");