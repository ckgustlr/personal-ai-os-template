// 1. 응답 데이터를 누적할 전역 리스트
window.nexacroDataStore = [];

// [추가] 쓰레기 트래픽 필터링용 블랙리스트
const BLACKLIST_DVO = [
    "anyframeDVO", "eventLoggingDVOList", "itemFilterDVO",
    "TbmSmCommEnvDVO", "loggingDVOList", "categoryDVO", "clientDateTimeDVO"
];

// 2. 안전한 XHR 2중 후킹
if (!window._secondaryOrigSend) {
    window._secondaryOrigSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(body) {
        this.addEventListener('load', function() {
            const resText = this.responseText || "";

            if (resText.startsWith("SSV:") || resText.includes("<?xml") || resText.includes("<Root")) {
                try {
                    let parsedData = parseNexacroData(resText);
                    if (Object.keys(parsedData).length > 0) {
                        window.nexacroDataStore.push({
                            url: this.responseURL ? this.responseURL.split('?')[0].split('/').pop() : "unknown_url",
                            timestamp: new Date().toISOString(),
                            datasets: parsedData
                        });
                    }
                } catch (e) {
                    console.error("넥사크로 데이터 파싱 중 에러 발생:", e);
                }
            }
        });
        return window._secondaryOrigSend.apply(this, arguments);
    };
}

// 3. 넥사크로 SSV / XML -> JSON 파서
function parseNexacroData(text) {
    let result = {};

    // [A] SSV 포맷 파싱
    if (text.startsWith("SSV:")) {
        const lines = text.split("\u001e");
        let currentDs = null;
        let headers = [];

        lines.forEach(line => {
            if (line.startsWith("Dataset:")) {
                let dsName = line.split(":")[1].trim();
                // 블랙리스트에 포함된 데이터셋은 아예 파싱 스킵
                if (BLACKLIST_DVO.includes(dsName)) {
                    currentDs = null;
                } else {
                    currentDs = dsName;
                    result[currentDs] = [];
                }
                headers = []; // ✅ [핵심 해결] 데이터셋이 바뀔 때 헤더 무조건 초기화
            } else if (currentDs && line.includes("_RowType_") && headers.length === 0) {
                // 컬럼 헤더 추출 (타입 정의 :string(32) 같은 건 날려버림)
                headers = line.split("\u001f").map(h => h.split(":")[0]);
            } else if (currentDs && headers.length > 0 && line.trim() !== "") {
                // 혹시 모를 ColumnInfo 메타데이터 라인 스킵 (방어 코드)
                if (line.startsWith("ColumnInfo:")) return;

                let values = line.split("\u001f");
                let rowObj = {};
                headers.forEach((h, i) => {
                    if (h && h !== "_RowType_" && h !== "Const") {
                        rowObj[h] = values[i] !== undefined ? values[i] : "";
                    }
                });
                if (Object.keys(rowObj).length > 0) result[currentDs].push(rowObj);
            }
        });
    }
    // [B] XML 포맷 파싱
    else if (text.includes("<Dataset")) {
        const dsBlocks = text.split(/<Dataset id="/).slice(1);
        dsBlocks.forEach(block => {
            const dsId = block.split('"')[0];

            // 블랙리스트 필터링
            if (BLACKLIST_DVO.includes(dsId)) return;

            result[dsId] = [];

            const rowsBlockMatch = block.match(/<Rows>([\s\S]*?)<\/Rows>/);
            if (rowsBlockMatch) {
                const rows = rowsBlockMatch[1].split("<Row>");
                rows.forEach(row => {
                    if (!row.includes("</Row>")) return;
                    let rowObj = {};
                    const colMatches = [...row.matchAll(/<Col id="([^"]+)">([^<]*)<\/Col>/g)];
                    colMatches.forEach(m => {
                        rowObj[m[1]] = m[2];
                    });
                    if (Object.keys(rowObj).length > 0) result[dsId].push(rowObj);
                });
            }
        });
    }
    return result;
}

// 4. Minify JSON 출력 함수
window.getMinifiedNexacroData = function() {
    const minifiedJson = JSON.stringify(window.nexacroDataStore);
    console.log(minifiedJson);

    if (navigator.clipboard) {
        navigator.clipboard.writeText(minifiedJson).then(() => {
            console.log("✅ 클립보드 복사 완료! 진짜 데이터가 예쁘게 들어갔을 겁니다.");
        }).catch(err => {
            console.log("⚠️ 클립보드 복사 실패. 콘솔 출력을 복사해주세요.");
        });
    }
    return "출력 완료";
};

console.log("�� [준비 완료] 수정된 넥사크로 파싱 스크립트가 로드되었습니다.");