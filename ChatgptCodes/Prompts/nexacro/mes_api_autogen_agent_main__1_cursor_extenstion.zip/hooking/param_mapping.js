function extractMappingWithEnumOptions() {
    let results = { simpleBinds: [], complexTrees: [] };
    let app = nexacro.getApplication();

    try {
        let workFrames = app.mainframe.vFrameSet1.vFrameSet2.hFrameSet1.workFrameSet.frames;
        if (!workFrames) return;

        function getBinds(formObj) {
            if (!formObj) return;

            if (formObj.binds && formObj.binds.length > 0) {
                for(let b=0; b<formObj.binds.length; b++) {
                    let bind = formObj.binds[b];
                    let compIdArr = bind.compid.split(".");
                    let targetComp = formObj;

                    for(let i=0; i<compIdArr.length; i++) {
                        if(targetComp[compIdArr[i]]) targetComp = targetComp[compIdArr[i]];
                        else if (targetComp.components && targetComp.components[compIdArr[i]]) targetComp = targetComp.components[compIdArr[i]];
                    }

                    let koreanLabel = "매핑실패";

                    if (targetComp && targetComp.parent && targetComp.parent.components) {
                        let siblings = targetComp.parent.components;
                        let targetX = targetComp.getOffsetLeft();
                        let targetY = targetComp.getOffsetTop();
                        let targetMidY = targetY + (targetComp.getOffsetHeight() / 2);

                        let minScore = 999999;

                        for (let i = 0; i < siblings.length; i++) {
                            let sib = siblings[i];

                            if (sib instanceof nexacro.Static && sib.text && sib !== targetComp) {
                                let sibX = sib.getOffsetLeft();
                                let sibY = sib.getOffsetTop();
                                let sibRightX = sibX + sib.getOffsetWidth();
                                let sibMidY = sibY + (sib.getOffsetHeight() / 2);

                                let isLeft = sibRightX <= targetX;
                                let isAbove = (sibY + sib.getOffsetHeight()) <= targetY;

                                let score = 999999;

                                if (isLeft) {
                                    let yDiff = Math.abs(targetMidY - sibMidY);
                                    let xGap = targetX - sibRightX;
                                    if (yDiff < 20) score = xGap + (yDiff * 10);
                                }
                                else if (isAbove) {
                                    let xDiff = Math.abs(targetX - sibX);
                                    let yGap = targetY - (sibY + sib.getOffsetHeight());
                                    if (xDiff < 30) score = yGap + (xDiff * 10) + 1000;
                                }

                                if (score < minScore && score < 5000) {
                                    minScore = score;
                                    koreanLabel = sib.text.replace(/\r\n|\n/g, " ").replace(/<[^>]*>?/gm, '').trim();
                                }
                            }
                        }
                    }

                    // �� [추가된 로직] Combo 또는 Radio의 내부 옵션(innerdataset) 추출
                    let enumOptions = [];
                    if (targetComp && targetComp.innerdataset) {
                        let dsName = targetComp.innerdataset;
                        let dataCol = targetComp.datacolumn;
                        let codeCol = targetComp.codecolumn;

                        // 데이터셋 객체 찾기 (폼 내부 objects, 폼 직속, 또는 글로벌)
                        let innerDsObj = formObj.objects[dsName] || formObj[dsName] || app.all[dsName];
                        if (typeof dsName === "object") innerDsObj = dsName; // 이미 객체로 연결된 경우

                        if (innerDsObj && typeof innerDsObj.getRowCount === "function") {
                            for (let r = 0; r < innerDsObj.getRowCount(); r++) {
                                enumOptions.push({
                                    uiText: innerDsObj.getColumn(r, dataCol),
                                    serverValue: innerDsObj.getColumn(r, codeCol)
                                });
                            }
                        }
                    }

                    results.simpleBinds.push({
                        uiLabel: koreanLabel,
                        compId: bind.compid,
                        datasetId: bind.datasetid,
                        columnId: bind.columnid,
                        options: enumOptions // 추출된 Enum 정보 배열 추가
                    });
                }
            }

            if (formObj.components) {
                for(let k=0; k<formObj.components.length; k++) {
                    let comp = formObj.components[k];
                    if (comp instanceof nexacro.Grid && comp.treeusebutton !== undefined) {
                         results.complexTrees.push({
                             type: "complex_tree",
                             compId: comp.name || comp.id,
                             bindDataset: comp.binddataset
                         });
                    }

                    if (comp.form) getBinds(comp.form);
                    else if (comp.tabpages) {
                        for(let t=0; t<comp.tabpages.length; t++) getBinds(comp.tabpages[t].form);
                    }
                }
            }
        }

        for (let i = 0; i < workFrames.length; i++) {
            if (workFrames[i].form) getBinds(workFrames[i].form);
        }

    } catch(e) {
        console.warn("에러 발생:", e);
    }

    console.log(JSON.stringify(results, null, null));
    return results;
}

extractMappingWithEnumOptions();