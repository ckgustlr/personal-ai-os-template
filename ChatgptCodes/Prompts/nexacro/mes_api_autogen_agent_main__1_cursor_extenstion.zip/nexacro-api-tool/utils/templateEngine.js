/**
 * Col values -> {{id}} placeholders; rebuild XML from user input.
 */

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function buildTemplateFromXmlDoc(doc, datasetId, columnIds) {
  const clone = doc.cloneNode(true);
  const datasets = clone.getElementsByTagNameNS("*", "Dataset");
  let target = null;
  for (let i = 0; i < datasets.length; i++) {
    const d = datasets[i];
    if ((d.getAttribute("id") || "") === datasetId) {
      target = d;
      break;
    }
  }
  if (!target) throw new Error("Dataset not found: " + datasetId);

  const rows = target.getElementsByTagNameNS("*", "Rows")[0];
  if (!rows) throw new Error("Rows not found on dataset: " + datasetId);
  const firstRow = rows.getElementsByTagNameNS("*", "Row")[0];
  if (!firstRow) throw new Error("Row not found on dataset: " + datasetId);

  const idSet = new Set(columnIds);
  const colNodes = firstRow.getElementsByTagNameNS("*", "Col");
  for (let i = 0; i < colNodes.length; i++) {
    const c = colNodes[i];
    const id = c.getAttribute("id");
    if (!id || !idSet.has(id)) continue;
    c.textContent = "{{" + id + "}}";
  }

  const serializer = new XMLSerializer();
  return serializer.serializeToString(clone);
}

function applyTemplate(templateString, values) {
  let out = templateString;
  for (const [k, v] of Object.entries(values)) {
    const re = new RegExp("\\{\\{" + escapeRegExp(k) + "\\}\\}", "g");
    out = out.replace(re, v == null ? "" : String(v));
  }
  return out;
}

function validateNoUnresolvedPlaceholders(xmlString) {
  const m = xmlString.match(/\{\{([a-zA-Z0-9_]+)\}\}/g);
  if (m && m.length) {
    throw new Error("Unresolved placeholders: " + m.join(", "));
  }
}

function yyyymmddToInputDate(y) {
  if (!y || String(y).length < 8) return "";
  const s = String(y);
  return s.slice(0, 4) + "-" + s.slice(4, 6) + "-" + s.slice(6, 8);
}

function inputDateToYyyymmdd(isoDate) {
  if (!isoDate) return "";
  const p = String(isoDate).replace(/-/g, "");
  return p.length >= 8 ? p.slice(0, 8) : p;
}

function yyyymmddhhmmssToDatetimeLocal(v) {
  const s = String(v || "");
  if (s.length < 14) return "";
  const y = s.slice(0, 4);
  const mo = s.slice(4, 6);
  const d = s.slice(6, 8);
  const h = s.slice(8, 10);
  const mi = s.slice(10, 12);
  const se = s.slice(12, 14);
  return `${y}-${mo}-${d}T${h}:${mi}:${se}`;
}

function datetimeLocalToNexacro(v) {
  if (!v) return "";
  const [date, time] = String(v).split("T");
  if (!date) return "";
  const ds = date.replace(/-/g, "");
  const ts = (time || "000000").replace(/:/g, "").slice(0, 6);
  return ds + ts.padEnd(6, "0");
}

export {
  buildTemplateFromXmlDoc,
  applyTemplate,
  validateNoUnresolvedPlaceholders,
  yyyymmddToInputDate,
  inputDateToYyyymmdd,
  yyyymmddhhmmssToDatetimeLocal,
  datetimeLocalToNexacro,
};
