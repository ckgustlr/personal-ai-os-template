/**
 * Nexacro Root XML parser: Dataset / Col / Parameter extraction.
 * For extension popup (DOMParser).
 */

const NS_ROOT = "http://www.nexacroplatform.com/platform/dataset";

function isDatasetElement(el) {
  if (!el || el.localName !== "Dataset") return false;
  const ns = el.namespaceURI;
  return !ns || ns === NS_ROOT;
}

function decodeRequestBodyFromWebRequest(requestBody) {
  if (!requestBody) return null;
  if (requestBody.raw && requestBody.raw[0] && requestBody.raw[0].bytes) {
    try {
      return new TextDecoder("utf-8").decode(requestBody.raw[0].bytes);
    } catch {
      return null;
    }
  }
  if (requestBody.formData) {
    try {
      return JSON.stringify(requestBody.formData);
    } catch {
      return null;
    }
  }
  return null;
}

function parseXmlString(xmlString) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, "application/xml");
  const err = doc.querySelector("parsererror");
  if (err) throw new Error("XML parse error: " + (err.textContent || "unknown"));
  return doc;
}

function listDatasetElements(doc) {
  const root = doc.documentElement;
  if (!root) return [];
  return Array.from(root.getElementsByTagNameNS("*", "Dataset")).filter(isDatasetElement);
}

function guessFilterDataset(datasets, preferredId) {
  if (preferredId) {
    const found = datasets.find((d) => d.id === preferredId);
    if (found) return found;
  }
  const byName = datasets.find(
    (d) => d.id && /filter/i.test(d.id)
  );
  if (byName) return byName;
  return datasets[0] || null;
}

function extractColumnsFromDataset(datasetEl) {
  const cols = [];
  const rows = datasetEl.getElementsByTagNameNS("*", "Rows")[0];
  if (!rows) return cols;
  const firstRow = rows.getElementsByTagNameNS("*", "Row")[0];
  if (!firstRow) return cols;
  const colNodes = firstRow.getElementsByTagNameNS("*", "Col");
  for (let i = 0; i < colNodes.length; i++) {
    const c = colNodes[i];
    const id = c.getAttribute("id");
    if (!id) continue;
    const text = (c.textContent || "").trim();
    cols.push({ id, value: text });
  }
  return cols;
}

function columnInfoMap(datasetEl) {
  const map = new Map();
  const ci = datasetEl.getElementsByTagNameNS("*", "ColumnInfo")[0];
  if (!ci) return map;
  const columns = ci.getElementsByTagNameNS("*", "Column");
  for (let i = 0; i < columns.length; i++) {
    const col = columns[i];
    const id = col.getAttribute("id");
    const type = (col.getAttribute("type") || "STRING").toUpperCase();
    if (id) map.set(id, type);
  }
  return map;
}

function inferFieldType(colId, value, columnType) {
  if (columnType === "INT" || columnType === "FLOAT" || columnType === "BIGDECIMAL")
    return "number";
  if (columnType === "DATE" || columnType === "TIME" || columnType === "DATETIME")
    return "date";
  const v = String(value || "");
  if (/^\d{8}$/.test(v) && /date|dt|from|to|start|end/i.test(colId)) return "date";
  if (/^\d{14,17}$/.test(v)) return "datetime";
  if (/^\d{8}$/.test(v)) return "date";
  if (/^-?\d+(\.\d+)?$/.test(v) && v !== "") return "number";
  return "string";
}

function summarizeDataset(doc, preferredDatasetId) {
  const datasets = listDatasetElements(doc).map((el) => ({
    element: el,
    id: el.getAttribute("id") || "",
  }));
  const meta = datasets.map(({ element, id }) => {
    const colInfos = columnInfoMap(element);
    const cols = extractColumnsFromDataset(element).map((c) => ({
      ...c,
      dataType: colInfos.get(c.id) || "STRING",
      fieldType: inferFieldType(c.id, c.value, colInfos.get(c.id)),
    }));
    return { id, columns: cols, columnInfo: Object.fromEntries(colInfos) };
  });
  const chosen = guessFilterDataset(meta, preferredDatasetId);
  return { datasets: meta, selected: chosen };
}

function getDatasetElementById(doc, datasetId) {
  const list = listDatasetElements(doc);
  for (let i = 0; i < list.length; i++) {
    if ((list[i].getAttribute("id") || "") === datasetId) return list[i];
  }
  return null;
}

export {
  NS_ROOT,
  decodeRequestBodyFromWebRequest,
  parseXmlString,
  listDatasetElements,
  guessFilterDataset,
  extractColumnsFromDataset,
  columnInfoMap,
  inferFieldType,
  summarizeDataset,
  getDatasetElementById,
};
