import {
  parseXmlString,
  summarizeDataset,
} from "./utils/xmlParser.js";
import {
  buildTemplateFromXmlDoc,
  applyTemplate,
  validateNoUnresolvedPlaceholders,
  yyyymmddToInputDate,
  inputDateToYyyymmdd,
  yyyymmddhhmmssToDatetimeLocal,
  datetimeLocalToNexacro,
} from "./utils/templateEngine.js";

const $ = (id) => document.getElementById(id);

function log(line) {
  const el = $("log");
  const t = new Date().toISOString().slice(11, 19);
  el.textContent = `[${t}] ${line}\n` + el.textContent;
}

function sendMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (r) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(r);
    });
  });
}

async function getState() {
  return sendMessage({ type: "GET_STATE" });
}

function downloadText(filename, text) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const u = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = u;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(u);
}

let parsedDoc = null;
let summary = null;
let selectedDatasetId = null;
let templateString = "";
let latestCapture = null;

function currentColumnMeta() {
  if (!summary || !selectedDatasetId) return [];
  const ds = summary.datasets.find((d) => d.id === selectedDatasetId);
  return ds ? ds.columns : [];
}

function collectValuesFromForm() {
  const cols = currentColumnMeta();
  const out = {};
  for (const c of cols) {
    const el = $(`f_${c.id}`);
    if (!el) continue;
    let v = el.value;
    if (c.fieldType === "date") {
      out[c.id] = inputDateToYyyymmdd(v);
    } else if (c.fieldType === "datetime") {
      out[c.id] = datetimeLocalToNexacro(v);
    } else if (c.fieldType === "number") {
      out[c.id] = v === "" ? "" : String(Number(v));
    } else {
      out[c.id] = v;
    }
  }
  return out;
}

function renderForm() {
  const host = $("formFields");
  host.innerHTML = "";
  const cols = currentColumnMeta();
  for (const c of cols) {
    const wrap = document.createElement("label");
    wrap.textContent = `${c.id} (${c.fieldType})`;
    let input;
    if (c.fieldType === "date") {
      input = document.createElement("input");
      input.type = "date";
      input.value = yyyymmddToInputDate(c.value);
    } else if (c.fieldType === "datetime") {
      input = document.createElement("input");
      input.type = "datetime-local";
      input.value = yyyymmddhhmmssToDatetimeLocal(c.value);
    } else if (c.fieldType === "number") {
      input = document.createElement("input");
      input.type = "number";
      input.step = "any";
      input.value = c.value;
    } else {
      input = document.createElement("input");
      input.type = "text";
      input.value = c.value;
    }
    input.id = `f_${c.id}`;
    input.name = c.id;
    wrap.appendChild(input);
    host.appendChild(wrap);
  }
  refreshMultiColSelects();
}

function refreshMultiColSelects() {
  const cols = currentColumnMeta();
  const fromSel = $("mqFromCol");
  const toSel = $("mqToCol");
  fromSel.innerHTML = "";
  toSel.innerHTML = "";
  for (const c of cols) {
    const o1 = document.createElement("option");
    o1.value = c.id;
    o1.textContent = c.id;
    fromSel.appendChild(o1);
    const o2 = document.createElement("option");
    o2.value = c.id;
    o2.textContent = c.id;
    toSel.appendChild(o2);
  }
  const guessFrom = cols.find((x) => /from/i.test(x.id));
  const guessTo = cols.find((x) => /to/i.test(x.id));
  if (guessFrom) fromSel.value = guessFrom.id;
  if (guessTo) toSel.value = guessTo.id;
}

function fillDatasetSelect() {
  const sel = $("datasetSelect");
  sel.innerHTML = "";
  if (!summary) return;
  for (const d of summary.datasets) {
    const o = document.createElement("option");
    o.value = d.id;
    o.textContent = d.id || "(no id)";
    sel.appendChild(o);
  }
  const preferred = summary.selected && summary.selected.id;
  sel.value = preferred || summary.datasets[0]?.id || "";
  selectedDatasetId = sel.value;
}

async function ingestXml(xml) {
  if (!xml || !String(xml).trim()) {
    parsedDoc = null;
    summary = null;
    return;
  }
  parsedDoc = parseXmlString(xml);
  selectedDatasetId = null;
  summary = summarizeDataset(parsedDoc, null);
  fillDatasetSelect();
  renderForm();
}

function updateHeader() {
  const u = $("captureUrl");
  if (latestCapture && latestCapture.url) {
    u.textContent = latestCapture.url;
  } else {
    u.textContent =
      "No capture yet. Open your MES tab, trigger ext.do, then Refresh.";
  }
}

function updatePill(enabled) {
  const pill = $("capturePill");
  pill.textContent = enabled ? "Capturing" : "Idle";
  pill.classList.toggle("on", enabled);
  pill.classList.toggle("off", !enabled);
}

async function refreshAll() {
  const st = await getState();
  updatePill(!!st.captureEnabled);
  latestCapture = st.latestCapture || null;
  updateHeader();
  const xml = latestCapture && latestCapture.requestXml;
  if (xml) {
    await ingestXml(xml);
  } else {
    $("formFields").innerHTML = "";
    $("datasetSelect").innerHTML = "";
  }
  if (st.pageContext && st.pageContext.mesApiStore != null) {
    log("Page probe: mesApiStore received (not expanded in UI).");
  }
}

function buildCurrentTemplate() {
  if (!parsedDoc || !selectedDatasetId) {
    throw new Error("No dataset parsed.");
  }
  const cols = currentColumnMeta().map((c) => c.id);
  if (!cols.length) throw new Error("No columns in dataset row.");
  return buildTemplateFromXmlDoc(parsedDoc, selectedDatasetId, cols);
}

async function executeXml(xmlBody) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab || !tab.id) throw new Error("No active tab.");
  const url = latestCapture && latestCapture.url;
  if (!url) throw new Error("No captured URL.");
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(
      tab.id,
      {
        type: "EXECUTE_NEXACRO",
        url,
        method: "POST",
        body: xmlBody,
      },
      (r) => {
        if (chrome.runtime.lastError) {
          resolve({
            ok: false,
            error: chrome.runtime.lastError.message,
          });
          return;
        }
        resolve(r || { ok: false, error: "no response" });
      }
    );
  });
}

function exportParamsPy() {
  const cap = latestCapture || {};
  const req = cap.requestXml || "";
  const res = cap.responseXml || "";
  const url = cap.url || "";
  const net = JSON.stringify({ url, method: cap.method || "POST" }, null, 2);
  const dict = JSON.stringify(
    {
      url,
      datasetId: selectedDatasetId,
      template: templateString || "",
      values: collectValuesFromForm(),
    },
    null,
    2
  );
  const body = `# Generated by Nexacro API Query Tool
NETWORK_JSON = r"""${net.replace(/\\/g, "\\\\").replace(/"""/g, '\\"\\"\\"')}"""
REQ_JSON = r"""${req.replace(/\\/g, "\\\\").replace(/"""/g, '\\"\\"\\"')}"""
RES_JSON = r"""${res.replace(/\\/g, "\\\\").replace(/"""/g, '\\"\\"\\"')}"""
NEXACRO_DICT = r"""${dict.replace(/\\/g, "\\\\").replace(/"""/g, '\\"\\"\\"')}"""
`;
  downloadText("params.py", body);
}

function exportJsonBundle() {
  const cap = latestCapture || {};
  const bundle = {
    url: cap.url,
    method: cap.method || "POST",
    requestXml: cap.requestXml || "",
    responseXml: cap.responseXml || "",
    datasetId: selectedDatasetId,
    template: templateString || "",
    formValues: collectValuesFromForm(),
    savedAt: new Date().toISOString(),
  };
  downloadText("nexacro_capture.json", JSON.stringify(bundle, null, 2));
}

$("datasetSelect").addEventListener("change", () => {
  selectedDatasetId = $("datasetSelect").value;
  if (parsedDoc) {
    summary = summarizeDataset(parsedDoc, selectedDatasetId);
    renderForm();
  }
});

$("btnStart").addEventListener("click", async () => {
  await sendMessage({ type: "SET_CAPTURE", enabled: true });
  log("Capture started.");
  await refreshAll();
});

$("btnStop").addEventListener("click", async () => {
  await sendMessage({ type: "SET_CAPTURE", enabled: false });
  log("Capture stopped.");
  await refreshAll();
});

$("btnReload").addEventListener("click", async () => {
  await refreshAll();
  log("State refreshed.");
});

$("btnTemplate").addEventListener("click", () => {
  try {
    templateString = buildCurrentTemplate();
    $("templateArea").value = templateString;
    log("Template generated.");
  } catch (e) {
    log("Template error: " + e.message);
  }
});

$("btnExecute").addEventListener("click", async () => {
  try {
    const tpl = $("templateArea").value || templateString;
    if (!tpl.trim()) {
      log("Template is empty.");
      return;
    }
    const values = collectValuesFromForm();
    const xml = applyTemplate(tpl, values);
    validateNoUnresolvedPlaceholders(xml);
    const r = await executeXml(xml);
    if (r.ok) {
      log(`OK HTTP ${r.status}, body ${(r.text || "").length} bytes`);
      latestCapture = {
        ...(latestCapture || {}),
        responseXml: r.text,
        lastExecutedAt: Date.now(),
      };
    } else {
      log("Execute failed: " + (r.error || r.status));
    }
  } catch (e) {
    log("Execute error: " + e.message);
  }
});

$("btnExportPy").addEventListener("click", () => {
  try {
    exportParamsPy();
    log("Downloaded params.py");
  } catch (e) {
    log("Export error: " + e.message);
  }
});

$("btnExportJson").addEventListener("click", () => {
  exportJsonBundle();
  log("Downloaded JSON");
});

$("btnSaveRegistry").addEventListener("click", async () => {
  const methodName =
    (latestCapture &&
      latestCapture.requestXml &&
      (latestCapture.requestXml.match(/methodName[^>]*>([^<]+)</) || [])[1]) ||
    "unknown";
  await sendMessage({
    type: "SAVE_REGISTRY_ENTRY",
    entry: {
      methodName: String(methodName).trim(),
      dataset: selectedDatasetId,
      template: $("templateArea").value || templateString,
      url: latestCapture && latestCapture.url,
      sampleValues: collectValuesFromForm(),
    },
  });
  log("Saved to registry (storage).");
});

$("multiEnabled").addEventListener("change", () => {
  $("multiPanel").style.display = $("multiEnabled").checked ? "block" : "none";
});

function addDaysIso(isoDateStr, days) {
  const d = new Date(isoDateStr + "T12:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

$("btnMultiRun").addEventListener("click", async () => {
  const tpl = $("templateArea").value || templateString;
  if (!tpl.trim()) {
    log("Generate a template first.");
    return;
  }
  const start = $("mqStart").value;
  const end = $("mqEnd").value;
  const step = Math.max(1, parseInt($("mqStep").value || "7", 10));
  const fromCol = $("mqFromCol").value;
  const toCol = $("mqToCol").value;
  if (!start || !end) {
    log("Multi-query: pick start and end dates.");
    return;
  }
  let cursor = start;
  let i = 0;
  while (cursor <= end) {
    const nextEnd = addDaysIso(cursor, step - 1);
    const windowEnd = nextEnd > end ? end : nextEnd;
    const values = collectValuesFromForm();
    values[fromCol] = inputDateToYyyymmdd(cursor);
    values[toCol] = inputDateToYyyymmdd(windowEnd);
    try {
      const xml = applyTemplate(tpl, values);
      validateNoUnresolvedPlaceholders(xml);
      const r = await executeXml(xml);
      if (r.ok) {
        log(
          `Window ${i + 1}: ${values[fromCol]}..${values[toCol]} -> HTTP ${r.status}`
        );
      } else {
        log(`Window ${i + 1} failed: ` + (r.error || r.status));
        break;
      }
    } catch (e) {
      log("Window error: " + e.message);
      break;
    }
    cursor = addDaysIso(windowEnd, 1);
    i++;
    if (i > 500) {
      log("Stopped at safety cap (500 windows).");
      break;
    }
  }
});

document.addEventListener("DOMContentLoaded", () => {
  refreshAll();
});
