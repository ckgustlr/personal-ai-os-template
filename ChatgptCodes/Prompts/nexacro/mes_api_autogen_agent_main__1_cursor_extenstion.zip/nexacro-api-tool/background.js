"use strict";

const EXT_DO_FILTER = { urls: ["*://*/*ext.do*", "*://*/*ext.do?*"] };

function decodeRequestBody(requestBody) {
  if (!requestBody) return null;
  if (requestBody.raw && requestBody.raw[0] && requestBody.raw[0].bytes) {
    try {
      return new TextDecoder("utf-8").decode(requestBody.raw[0].bytes);
    } catch {
      return null;
    }
  }
  if (requestBody.formData) {
    try {
      return JSON.stringify(requestBody.formData);
    } catch {
      return null;
    }
  }
  return null;
}

function now() {
  return Date.now();
}

async function getCaptureEnabled() {
  const r = await chrome.storage.local.get(["captureEnabled"]);
  return !!r.captureEnabled;
}

async function saveLatestCapture(payload) {
  const prev = await chrome.storage.local.get(["latestCapture"]);
  const merged = {
    ...prev.latestCapture,
    ...payload,
    savedAt: now(),
  };
  await chrome.storage.local.set({ latestCapture: merged });
}

const pendingByKey = new Map();

function keyFor(tabId, url) {
  return `${tabId || 0}::${url}`;
}

chrome.webRequest.onBeforeRequest.addListener(
  async (details) => {
    if (!(await getCaptureEnabled())) return;
    if (details.method !== "POST") return;
    const body = decodeRequestBody(details.requestBody);
    if (!body) return;
    const k = keyFor(details.tabId, details.url);
    pendingByKey.set(k, {
      url: details.url,
      requestXml: body,
      method: details.method,
      time: now(),
      tabId: details.tabId,
    });
  },
  EXT_DO_FILTER,
  ["requestBody"]
);

chrome.webRequest.onCompleted.addListener(
  async (details) => {
    if (!(await getCaptureEnabled())) return;
    const k = keyFor(details.tabId, details.url);
    const p = pendingByKey.get(k);
    if (!p || now() - p.time > 120000) {
      pendingByKey.delete(k);
      return;
    }
    pendingByKey.delete(k);
    const cur = await chrome.storage.local.get(["latestCapture"]);
    const latest = cur.latestCapture;
    if (latest && latest.url === p.url && latest.responseXml) return;
    await saveLatestCapture({
      url: p.url,
      requestXml: p.requestXml,
      method: p.method,
      statusCode: details.statusCode,
      source: "webRequest",
    });
  },
  EXT_DO_FILTER
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "SET_CAPTURE") {
      await chrome.storage.local.set({ captureEnabled: !!message.enabled });
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === "GET_STATE") {
      const data = await chrome.storage.local.get([
        "captureEnabled",
        "latestCapture",
        "apiRegistry",
        "pageContext",
      ]);
      sendResponse(data);
      return;
    }
    if (message?.type === "NEXACRO_XHR_CAPTURE") {
      if (!(await getCaptureEnabled())) {
        sendResponse({ ok: false, reason: "capture_off" });
        return;
      }
      const tabId = sender.tab?.id || 0;
      const k = keyFor(tabId, message.url);
      const fromWR = pendingByKey.get(k);
      const requestXml =
        message.requestXml ||
        (fromWR && fromWR.requestXml) ||
        null;
      if (fromWR) pendingByKey.delete(k);
      await saveLatestCapture({
        url: message.url,
        requestXml,
        responseXml: message.responseXml,
        method: message.method || "POST",
        source: "content_xhr",
      });
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === "PAGE_STORE") {
      await chrome.storage.local.set({
        pageContext: {
          mesApiStore: message.mesApiStore,
          paramMapping: message.paramMapping,
          at: now(),
        },
      });
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === "SAVE_REGISTRY_ENTRY") {
      const { entry } = message;
      const cur = await chrome.storage.local.get(["apiRegistry"]);
      const list = Array.isArray(cur.apiRegistry) ? cur.apiRegistry : [];
      list.unshift({
        ...entry,
        savedAt: now(),
      });
      await chrome.storage.local.set({ apiRegistry: list.slice(0, 200) });
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === "CLEAR_REGISTRY") {
      await chrome.storage.local.set({ apiRegistry: [] });
      sendResponse({ ok: true });
      return;
    }
    sendResponse({ ok: false, reason: "unknown_message" });
  })();
  return true;
});
