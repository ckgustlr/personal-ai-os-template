"use strict";

(function initNexacroCapture() {
  const EXT_RE = /ext\.do(\?|$)/i;

  function shouldCaptureUrl(url) {
    try {
      return EXT_RE.test(String(url));
    } catch {
      return false;
    }
  }

  function sendCapture(payload) {
    try {
      chrome.runtime.sendMessage({ type: "NEXACRO_XHR_CAPTURE", ...payload });
    } catch {
      /* extension context invalidated */
    }
  }

  let lastMesApiSnapshot = "";
  function readStoreAndForward() {
    try {
      if (typeof window.mesApiStore === "undefined") return;
      let snap = "";
      try {
        snap = JSON.stringify(window.mesApiStore);
      } catch {
        snap = "[unserializable mesApiStore]";
      }
      if (snap === lastMesApiSnapshot) return;
      lastMesApiSnapshot = snap;
      chrome.runtime.sendMessage({
        type: "PAGE_STORE",
        mesApiStore: window.mesApiStore,
        paramMapping: null,
      });
    } catch {
      /* ignore */
    }
  }

  const XOpen = XMLHttpRequest.prototype.open;
  const XSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    try {
      this.__nexMethod = method;
      this.__nexUrl = url;
    } catch {
      /* ignore */
    }
    return XOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const url = this.__nexUrl;
    const method = this.__nexMethod;
    if (shouldCaptureUrl(url)) {
      let reqText = null;
      if (typeof body === "string") reqText = body;
      else if (body instanceof Document) {
        try {
          reqText = new XMLSerializer().serializeToString(body);
        } catch {
          reqText = null;
        }
      }
      this.addEventListener("load", function () {
        sendCapture({
          url: this.responseURL || url,
          method,
          requestXml: reqText,
          responseXml:
            typeof this.responseText === "string" ? this.responseText : "",
        });
      });
    }
    return XSend.call(this, body);
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : input && input.url;
    const method = (init && init.method) || "GET";
    const p = origFetch.apply(this, arguments);
    if (!shouldCaptureUrl(url)) return p;

    let reqText = null;
    if (init && init.body != null && typeof init.body === "string") {
      reqText = init.body;
    }

    return p.then((res) => {
      try {
        const clone = res.clone();
        clone.text().then((text) => {
          sendCapture({
            url: res.url || url,
            method,
            requestXml: reqText,
            responseXml: text,
          });
        });
      } catch {
        /* ignore */
      }
      return res;
    });
  };

  window.addEventListener("load", () => {
    readStoreAndForward();
    setInterval(readStoreAndForward, 8000);
  });

  if (document.readyState === "complete" || document.readyState === "interactive") {
    readStoreAndForward();
  } else {
    document.addEventListener("DOMContentLoaded", readStoreAndForward);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "EXECUTE_NEXACRO") {
      const headers = {
        "Content-Type": "application/xml",
        Accept: "*/*",
        ...(msg.headers && typeof msg.headers === "object" ? msg.headers : {}),
      };
      fetch(msg.url, {
        method: msg.method || "POST",
        headers,
        body: msg.body,
        credentials: "include",
      })
        .then((r) =>
          r.text().then((text) =>
            sendResponse({
              ok: r.ok,
              status: r.status,
              text,
            })
          )
        )
        .catch((e) => sendResponse({ ok: false, status: 0, error: String(e) }));
      return true;
    }
    return undefined;
  });
})();
