import json
import requests

from params import NETWORK_JSON, RES_JSON, NEXACRO_DICT, REQ_JSON
from parser import parse_nexacro_raw_to_dict
from res_handler import transform_nexacro_to_ui_table


def execute_test():
    # try:
    #     with open("base_template.xml", "r", encoding="utf-8") as f:
    #         template = f.read()
    # except FileNotFoundError:
    #     raise Exception("base_template.xml missing")
    #
    # url = "http://gumimes4.sec.samsung.net/mes4/pm/ext.do" # 실제 MES 도메인으로 변경 필요, 추후 url주소까지 자동 수집 할것.
    # headers = {"Content-Type": "application/xml"}
    #
    # response = requests.post(url, data=template.encode('utf-8'), headers=headers)
    #
    # if response.status_code != 200:
    #     raise Exception(f"MES 서버 에러: {response.status_code}")
    #
    # dict_res = parse_nexacro_raw_to_dict(response.text)

    nexa_dict_list = json.loads(NEXACRO_DICT)
    network_json = json.loads(NETWORK_JSON)
    res_mapping = json.loads(RES_JSON)
    req_mapping = json.loads(REQ_JSON)


    for nexa_dict in nexa_dict_list:
        res = transform_nexacro_to_ui_table(network_json, res_mapping, nexa_dict['datasets'])
        print("ASDF")



if __name__ == '__main__':
    execute_test()