import xml.etree.ElementTree as ET


def parse_nexacro_raw_to_dict(raw_text: str) -> dict:
    """
    넥사크로의 XML 또는 SSV 포맷 응답 문자열을 파이썬 Dictionary 형식으로 파싱합니다.
    결과 포맷: {"DatasetID": [{"col1": "val1", "col2": "val2"}, ...]}
    """
    result = {}
    if not raw_text:
        return result

    # ==========================================
    # 1. SSV 포맷 파싱
    # ==========================================
    if raw_text.startswith("SSV:"):
        # \x1e (ASCII 30, Record Separator) : 줄(Row) 바꿈 단위
        lines = raw_text.split('\x1e')
        current_ds = None
        columns = []

        for line in lines:
            if line.startswith("Dataset:"):
                # 예: Dataset:dsListR4311UM0001DVO
                current_ds = line.split(":")[1].strip()
                result[current_ds] = []
                columns = []  # 데이터셋이 바뀌면 컬럼 초기화

            elif current_ds and "_RowType_" in line and not columns:
                # \x1f (ASCII 31, Unit Separator) : 칸(Column) 바꿈 단위
                # 헤더 라인 파싱 (예: _RowType_ \x1f col1:STRING(256) \x1f col2:INT)
                raw_cols = line.split('\x1f')
                # 타입 선언부 제거하고 컬럼명만 추출
                columns = [c.split(':')[0] for c in raw_cols]

            elif current_ds and columns:
                # 실제 데이터 라인 파싱
                values = line.split('\x1f')

                # 빈 줄이거나 유효하지 않은 데이터인 경우 스킵
                if not values or (len(values) == 1 and values[0] == ""):
                    continue

                row_dict = {}
                for i, col_name in enumerate(columns):
                    # 쓰레기 필드 차단 로직 (인수인계서 블랙리스트 참고)
                    if col_name in ["_RowType_", "_dynamicColumnList", "_status", "_checked", "_action"]:
                        continue

                    # 인덱스 에러 방지 (컬럼 수보다 데이터 수가 적을 수 있음)
                    row_dict[col_name] = values[i] if i < len(values) else ""

                result[current_ds].append(row_dict)

    # ==========================================
    # 2. XML 포맷 파싱
    # ==========================================
    elif "<?xml" in raw_text or "<Root" in raw_text:
        try:
            # XML 루트 요소 로드 (인코딩 선언 이슈 방지를 위해 루트 태그 시작점부터 슬라이싱하는 꼼수 추가)
            start_idx = raw_text.find('<Root')
            if start_idx == -1:
                return result

            xml_str = raw_text[start_idx:]
            root = ET.fromstring(xml_str)

            # 모든 Dataset 태그 순회
            for ds in root.findall(".//Dataset"):
                ds_id = ds.attrib.get("id")
                if not ds_id:
                    continue

                result[ds_id] = []

                # a. 컬럼 정보 추출
                columns = []
                for col in ds.findall(".//ColumnInfo/Column"):
                    col_id = col.attrib.get("id")
                    if col_id and col_id not in ["_RowType_", "_dynamicColumnList", "_status", "_checked", "_action"]:
                        columns.append(col_id)

                # b. 데이터 행(Row) 추출
                for row in ds.findall(".//Rows/Row"):
                    row_dict = {col: "" for col in columns}  # 빈 값으로 초기화

                    for col_node in row.findall("Col"):
                        col_id = col_node.attrib.get("id")
                        if col_id in row_dict:
                            # 텍스트가 없으면(None) 빈 문자열로 처리
                            row_dict[col_id] = col_node.text or ""

                    result[ds_id].append(row_dict)

        except ET.ParseError as e:
            print(f"XML 파싱 에러: {e}")

    return result