import re
from typing import Any, Dict, List, Union, Optional

def ssv_to_json(
    data: Union[str, bytes],
    *,
    rs: Optional[str] = None,
    us: Optional[str] = None,
    etx: str = "\x03",
    cast_types: bool = False,
) -> Dict[str, Any]:
    """
    Convert Nexacro SSV text/bytes into a JSON-friendly dict.

    Returns:
    {
      "variables": {name: value, ...},
      "datasets": {
        "<datasetId>": {
          "const": {...},
          "columns": [col1, col2, ...],
          "types": {col: "STRING"/"INT"/"DECIMAL"/...},
          "records": [
            {"_rowtype":"N","col1":..., "col2":...},
            ...
          ]
        },
        ...
      }
    }

    Args:
      data: SSV payload (str or bytes). First record may be 'SSV:<codepage>'.
      rs: record separator override (default: \x1E per Nexacro).
      us: unit/field separator override (default: \x1F per Nexacro).
      etx: value treated as NULL (default: \x03).
      cast_types: if True, cast INT to int, FLOAT/DECIMAL/BIGDECIMAL to float.
    """
    # --- helpers -------------------------------------------------------------
    def _guess_encoding(first_segment: str) -> Optional[str]:
        # header looks like "SSV:utf-8" or "SSV:en_US" etc.
        if not first_segment.startswith("SSV"):
            return None
        if ":" in first_segment:
            cp = first_segment.split(":", 1)[1].strip()
            cp_l = cp.lower()
            if "utf" in cp_l:
                return "utf-8"
            if "euc" in cp_l or "ksc" in cp_l or "cp949" in cp_l:
                return "euc-kr"
        return None

    def _decode_if_needed(d: Union[str, bytes]) -> str:
        if isinstance(d, str):
            return d
        # provisional split on default RS to read header reasonably
        probe = d.split(b"\x1e", 1)[0]
        enc = _guess_encoding(probe.decode("ascii", errors="ignore"))
        enc = enc or "utf-8"
        try:
            return d.decode(enc, errors="replace")
        except LookupError:
            return d.decode("utf-8", errors="replace")

    def _split_segments(text: str, rs_char: str) -> List[str]:
        return text.split(rs_char)

    def _parse_type_len(s: str) -> (Optional[str], Optional[int]):
        # e.g. "STRING(20)" -> ("STRING", 20) ; "INT" -> ("INT", None)
        m = re.match(r"^\s*([A-Za-z]+)(?:\((\d+)\))?\s*$", s)
        if not m:
            return None, None
        t = m.group(1).upper()
        ln = int(m.group(2)) if m.group(2) else None
        return t, ln

    def _cast(val: Optional[str], typ: Optional[str]) -> Any:
        if val is None:
            return None
        if typ is None or not cast_types:
            return val
        t = typ.upper()
        if val == "":
            return None
        if t in ("INT",):
            try:
                return int(val)
            except ValueError:
                return val
        if t in ("FLOAT", "DECIMAL", "BIGDECIMAL"):
            try:
                return float(val)
            except ValueError:
                return val
        # DATE/TIME/DATETIME/BLOB: leave as string by default
        return val

    # --- main ---------------------------------------------------------------
    text = _decode_if_needed(data)

    # default RS/US if not provided
    rs_char = rs if rs is not None else "\x1e"  # RS 0x1E
    us_char = us if us is not None else "\x1f"  # US 0x1F

    segments = _split_segments(text, rs_char)

    variables: Dict[str, Any] = {}
    datasets: Dict[str, Any] = {}

    i = 0
    # header
    if i < len(segments) and segments[i].startswith("SSV"):
        i += 1

    current_ds = None
    current_columns: List[str] = []
    current_types: Dict[str, str] = {}
    current_const: Dict[str, Any] = {}
    current_records: List[Dict[str, Any]] = []

    def _finalize_dataset():
        nonlocal current_ds, current_columns, current_types, current_const, current_records
        if current_ds is not None:
            datasets[current_ds] = {
                "const": current_const,
                "columns": current_columns[:],
                "types": dict(current_types),
                "records": current_records[:],
            }
        current_ds = None
        current_columns = []
        current_types = {}
        current_const = {}
        current_records = []

    # parse loop
    while i < len(segments):
        seg = segments[i]
        i += 1
        if not seg:
            continue

        # Dataset start
        if seg.startswith("Dataset:"):
            _finalize_dataset()
            current_ds = seg.split(":", 1)[1].strip()
            continue

        # ColumnInfo
        if seg.startswith("_RowType_"):
            parts = seg.split(us_char)
            # parts[0] == "_RowType_"
            current_columns = []
            current_types = {}
            for token in parts[1:]:
                token = token.strip()
                if not token:
                    continue
                # "Col:TYPE(LEN):SUM:TEXT" or "Col:TYPE"
                bits = token.split(":")
                col = bits[0]
                t = None
                if len(bits) >= 2 and bits[1]:
                    t, _ = _parse_type_len(bits[1])
                current_columns.append(col)
                if t:
                    current_types[col] = t
            continue

        # Const columns
        if seg.startswith("_Const_"):
            parts = seg.split(us_char)
            for token in parts[1:]:
                if not token:
                    continue
                # form: "ConstCol:TYPE(LEN)=Value" or "ConstCol=Value"
                name, val = token, ""
                if "=" in token:
                    name, val = token.split("=", 1)
                name = name.strip()
                typ = None
                if ":" in name:
                    name_only, typ_part = name.split(":", 1)
                    typ, _ = _parse_type_len(typ_part)
                    name = name_only
                val = None if val == etx else val
                current_const[name] = _cast(val, typ)
            continue

        # records (only when inside a dataset)
        if current_ds is not None:
            parts = seg.split(us_char)
            if not parts or parts[0] == "":
                continue
            rowtype = parts[0]
            values = parts[1:]
            row: Dict[str, Any] = {"_rowtype": rowtype}
            for idx, col in enumerate(current_columns):
                val = values[idx] if idx < len(values) else ""
                if val == etx:
                    val = None
                typ = current_types.get(col)
                row[col] = _cast(val, typ)
            current_records.append(row)
            continue

        # variables (outside of any dataset)
        # format: "Var[:TYPE(LEN)]=value"
        if "=" in seg:
            name, val = seg.split("=", 1)
            typ = None
            name = name.strip()
            if ":" in name:
                name_only, typ_part = name.split(":", 1)
                typ, _ = _parse_type_len(typ_part)
                name = name_only
            val = None if val == etx else val
            variables[name] = _cast(val, typ)

    # finalize last dataset if any
    _finalize_dataset()
    return {"variables": variables, "datasets": datasets}